"""
data_loader.py
==============
CSV se spot aur options data load karne ki class.
Ek baar load karo, baar baar use karo — no MongoDB needed.
"""

import pandas as pd
from datetime import datetime, date, time
from typing import Optional
import os


class DataLoader:
    """
    CSV files se spot + option data load karta hai.
    Strategy classes isko use karti hain data fetch karne ke liye.

    Usage:
        loader = DataLoader(
            spot_csv   = "exports/export_spot.csv",
            option_csv = "exports/export_options.csv"
        )
        loader.load()

        spot  = loader.get_spot(datetime(2023, 1, 4, 9, 20))
        price = loader.get_option_price(
                    trade_date  = date(2023, 1, 4),
                    expiry_date = date(2023, 1, 5),
                    strike      = 18200.0,
                    opt_type    = 1,          # 1=CE, 2=PE
                    candle_time = time(9, 20)
                )
    """

    def __init__(self, spot_csv: str, option_csv: str):
        self.spot_csv   = spot_csv
        self.option_csv = option_csv

        # Internal dataframes
        self._spot_df   = None
        self._option_df = None

        # Fast lookup indexes
        self._spot_index   = {}   # key: datetime → ClosePrice
        self._option_index = {}   # key: (candle_dt, expiry_date, strike, opt_type) → ClosePrice

        self._loaded = False

    # ─────────────────────────────────────────
    # LOAD
    # ─────────────────────────────────────────

    def load(self):
        """Load both CSVs into memory and build indexes."""
        print("DataLoader: Loading CSVs ...")

        if not os.path.exists(self.spot_csv):
            raise FileNotFoundError(f"Spot CSV not found: {self.spot_csv}")
        if not os.path.exists(self.option_csv):
            raise FileNotFoundError(f"Option CSV not found: {self.option_csv}")

        self._load_spot()
        self._load_options()

        self._loaded = True
        print("DataLoader: ✓ Ready!\n")

    def _load_spot(self):
        print(f"  Loading spot  : {self.spot_csv}")
        df = pd.read_csv(self.spot_csv)

        # Normalize timestamp column
        df["CandleTimeStamp"] = pd.to_datetime(df["CandleTimeStamp"])

        self._spot_df = df

        # Build index: datetime → ClosePrice
        for _, row in df.iterrows():
            key = row["CandleTimeStamp"].to_pydatetime()
            self._spot_index[key] = float(row["ClosePrice"])

        print(f"    Rows   : {len(df):,}")
        print(f"    Range  : {df['CandleTimeStamp'].min()} → {df['CandleTimeStamp'].max()}")

    def _load_options(self):
        print(f"  Loading options: {self.option_csv}")
        df = pd.read_csv(self.option_csv)

        # Normalize timestamps
        df["CandleTimeStamp"] = pd.to_datetime(df["CandleTimeStamp"])
        df["ExpiryDate"]      = pd.to_datetime(df["ExpiryDate"])

        # Normalize StrikePrice to float
        df["StrikePrice"] = df["StrikePrice"].astype(float)

        # Normalize OptionType to int
        df["OptionType"] = df["OptionType"].astype(int)

        self._option_df = df

        # Build index: (candle_dt, expiry_dt, strike, opt_type) → ClosePrice
        for _, row in df.iterrows():
            key = (
                row["CandleTimeStamp"].to_pydatetime(),
                row["ExpiryDate"].to_pydatetime(),
                float(row["StrikePrice"]),
                int(row["OptionType"]),
            )
            self._option_index[key] = float(row["ClosePrice"])

        print(f"    Rows   : {len(df):,}")
        print(f"    Range  : {df['CandleTimeStamp'].min()} → {df['CandleTimeStamp'].max()}")

    # ─────────────────────────────────────────
    # GET SPOT
    # ─────────────────────────────────────────

    def get_spot(self, candle_dt: datetime) -> Optional[float]:
        """
        Spot price fetch karo given datetime.
        candle_dt example: datetime(2023, 1, 4, 9, 20)
        """
        self._check_loaded()
        return self._spot_index.get(candle_dt, None)

    # ─────────────────────────────────────────
    # GET OPTION PRICE
    # ─────────────────────────────────────────

    def get_option_price(self,
                         trade_date : date,
                         expiry_date: date,
                         strike     : float,
                         opt_type   : int,
                         candle_time: time) -> Optional[float]:
        """
        Option close price fetch karo.

        Args:
            trade_date  : Jis din ka candle chahiye (date)
            expiry_date : Option ki expiry (date)
            strike      : Strike price (float, nearest 50)
            opt_type    : 1 = CE, 2 = PE
            candle_time : time(9, 20) ya time(15, 30)

        Returns:
            ClosePrice (float) ya None agar data nahi mila
        """
        self._check_loaded()

        candle_dt  = datetime.combine(trade_date,  candle_time)
        expiry_dt  = datetime.combine(expiry_date, time(0, 0, 0))

        key = (candle_dt, expiry_dt, float(strike), int(opt_type))
        return self._option_index.get(key, None)

    # ─────────────────────────────────────────
    # UTILITY
    # ─────────────────────────────────────────

    def get_all_expiries(self) -> list:
        """
        Option data se saari unique expiry dates nikalo — sorted.
        Strategy loop ke liye use karo.
        """
        self._check_loaded()
        expiries = self._option_df["ExpiryDate"].dt.date.unique()
        return sorted(expiries)

    def get_date_range(self):
        """Data ka start aur end date."""
        self._check_loaded()
        start = self._option_df["CandleTimeStamp"].min()
        end   = self._option_df["CandleTimeStamp"].max()
        return start, end

    def summary(self):
        """Quick summary print karo."""
        self._check_loaded()
        start, end = self.get_date_range()
        expiries   = self.get_all_expiries()
        print(f"DataLoader Summary:")
        print(f"  Spot rows    : {len(self._spot_df):,}")
        print(f"  Option rows  : {len(self._option_df):,}")
        print(f"  Date range   : {start.date()} → {end.date()}")
        print(f"  Expiries     : {len(expiries)}")

    def _check_loaded(self):
        if not self._loaded:
            raise RuntimeError("DataLoader.load() pehle call karo!")
