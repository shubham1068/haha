"""
iron_condor_strategy.py
=======================
Iron Condor strategy — BaseStrategy ko inherit karta hai.
Data DataLoader se aata hai (CSV).

Usage:
    from data_loader         import DataLoader
    from iron_condor_strategy import IronCondorStrategy

    loader = DataLoader("exports/export_spot.csv",
                        "exports/export_options.csv")
    loader.load()

    strategy = IronCondorStrategy(loader)
    trades   = strategy.run()
"""

from data_loader    import DataLoader
from strategy_base  import BaseStrategy, TradeResult
from datetime       import datetime, date, time, timedelta
from typing         import List


class IronCondorStrategy(BaseStrategy):
    """
    Nifty Weekly Iron Condor:
      Entry : 1 day before expiry (DTE1) @ 09:20
      Exit  : Expiry day (DTE0) @ 15:30
      Legs  : SELL CE ×1.007 | BUY CE ×1.015
              SELL PE ×0.993 | BUY PE ×0.985
    """

    # ── Default config ─────────────────────────────────────
    DEFAULT_CONFIG = {
        "sell_ce_mult"  : 1.007,
        "buy_ce_mult"   : 1.015,
        "sell_pe_mult"  : 0.993,
        "buy_pe_mult"   : 0.985,
        "strike_step"   : 50,
        "entry_time"    : time(9, 20),
        "exit_time"     : time(15, 30),
        "slippage_sell" : 0.05,
        "slippage_buy"  : 0.05,
        "lot_size"      : 75,
        "num_lots"      : 1,
    }

    CE = 1
    PE = 2

    def __init__(self, data_loader: DataLoader, config: dict = None):
        # Merge default + user config
        merged = {**self.DEFAULT_CONFIG, **(config or {})}
        super().__init__(data_loader, merged)

    @property
    def strategy_name(self) -> str:
        return "Nifty Iron Condor (DTE1→DTE0)"

    # ─────────────────────────────────────────
    # MAIN LOGIC
    # ─────────────────────────────────────────

    def generate_trades(self) -> List[TradeResult]:
        expiries = self.loader.get_all_expiries()
        print(f"  Expiries found: {len(expiries)}")

        results = []

        for expiry in expiries:
            entry_date = expiry - timedelta(days=1)   # DTE1
            exit_date  = expiry                        # DTE0

            entry_time : time = self.config["entry_time"]
            exit_time  : time = self.config["exit_time"]

            result = TradeResult(
                entry_date  = entry_date.strftime("%Y-%m-%d"),
                entry_day   = datetime.combine(entry_date, time()).strftime("%A"),
                entry_time  = entry_time.strftime("%H:%M"),
                exit_date   = exit_date.strftime("%Y-%m-%d"),
                exit_day    = datetime.combine(exit_date, time()).strftime("%A"),
                exit_time   = exit_time.strftime("%H:%M"),
                hold_days   = (exit_date - entry_date).days,
                expiry_date = expiry.strftime("%Y-%m-%d"),
                lot_size    = self.config["lot_size"],
                num_lots    = self.config["num_lots"],
            )

            # ── Spot ──────────────────────────────────
            entry_dt = datetime.combine(entry_date, entry_time)
            spot = self.loader.get_spot(entry_dt)

            if spot is None:
                result.skipped     = True
                result.skip_reason = f"No spot at {entry_dt}"
                self._update_stats(result)
                results.append(result)
                print(f"  [{expiry}] ✗ No spot. Skipping.")
                continue

            result.spot_at_entry = round(spot, 2)

            # ── Strikes ───────────────────────────────
            sell_ce = self.round_strike(spot * self.config["sell_ce_mult"])
            buy_ce  = self.round_strike(spot * self.config["buy_ce_mult"])
            sell_pe = self.round_strike(spot * self.config["sell_pe_mult"])
            buy_pe  = self.round_strike(spot * self.config["buy_pe_mult"])

            # ── Entry prices ──────────────────────────
            sell_ce_entry = self.loader.get_option_price(
                entry_date, expiry, sell_ce, self.CE, entry_time)
            buy_ce_entry  = self.loader.get_option_price(
                entry_date, expiry, buy_ce,  self.CE, entry_time)
            sell_pe_entry = self.loader.get_option_price(
                entry_date, expiry, sell_pe, self.PE, entry_time)
            buy_pe_entry  = self.loader.get_option_price(
                entry_date, expiry, buy_pe,  self.PE, entry_time)

            if any(p is None for p in [sell_ce_entry, buy_ce_entry,
                                        sell_pe_entry, buy_pe_entry]):
                result.skipped     = True
                result.skip_reason = (f"Entry price missing: "
                                      f"SELL_CE={sell_ce_entry} "
                                      f"BUY_CE={buy_ce_entry} "
                                      f"SELL_PE={sell_pe_entry} "
                                      f"BUY_PE={buy_pe_entry}")
                self._update_stats(result)
                results.append(result)
                print(f"  [{expiry}] ✗ {result.skip_reason}")
                continue

            # ── Exit prices ───────────────────────────
            sell_ce_exit = self.loader.get_option_price(
                exit_date, expiry, sell_ce, self.CE, exit_time) or 0.0
            buy_ce_exit  = self.loader.get_option_price(
                exit_date, expiry, buy_ce,  self.CE, exit_time) or 0.0
            sell_pe_exit = self.loader.get_option_price(
                exit_date, expiry, sell_pe, self.PE, exit_time) or 0.0
            buy_pe_exit  = self.loader.get_option_price(
                exit_date, expiry, buy_pe,  self.PE, exit_time) or 0.0

            # ── Slippage ──────────────────────────────
            ss = self.config["slippage_sell"]
            sb = self.config["slippage_buy"]

            sell_ce_entry_as = sell_ce_entry - ss
            buy_ce_entry_as  = buy_ce_entry  + sb
            sell_pe_entry_as = sell_pe_entry - ss
            buy_pe_entry_as  = buy_pe_entry  + sb

            sell_ce_exit_as  = sell_ce_exit  + sb
            buy_ce_exit_as   = buy_ce_exit   - ss
            sell_pe_exit_as  = sell_pe_exit  + sb
            buy_pe_exit_as   = buy_pe_exit   - ss

            # ── PnL per unit ──────────────────────────
            call_pnl = (sell_ce_entry_as - sell_ce_exit_as) + \
                       (buy_ce_exit_as   - buy_ce_entry_as)
            put_pnl  = (sell_pe_entry_as - sell_pe_exit_as) + \
                       (buy_pe_exit_as   - buy_pe_entry_as)
            net_unit = call_pnl + put_pnl
            net_pnl  = net_unit * self.config["lot_size"] * self.config["num_lots"]

            # ── Max profit / loss ─────────────────────
            max_profit_unit = (sell_ce_entry_as - buy_ce_entry_as) + \
                              (sell_pe_entry_as - buy_pe_entry_as)
            ce_wing         = buy_ce  - sell_ce
            pe_wing         = sell_pe - buy_pe
            max_loss_unit   = max(ce_wing, pe_wing) - max_profit_unit
            max_profit_rs   = max_profit_unit * self.config["lot_size"] * self.config["num_lots"]
            max_loss_rs     = max_loss_unit   * self.config["lot_size"] * self.config["num_lots"]

            # ── Premium summary ───────────────────────
            combined_sell   = sell_ce_entry + sell_pe_entry
            combined_buy    = buy_ce_entry  + buy_pe_entry
            net_credit_raw  = combined_sell - combined_buy
            net_credit_slip = (sell_ce_entry_as + sell_pe_entry_as) - \
                              (buy_ce_entry_as  + buy_pe_entry_as)

            pnl_pct = (net_pnl / abs(max_loss_rs) * 100) if max_loss_rs != 0 else 0.0

            # ── Fill result ───────────────────────────
            result.leg1_desc        = f"SELL CE {int(sell_ce)}"
            result.leg1_entry_price = round(sell_ce_entry, 2)
            result.leg1_exit_price  = round(sell_ce_exit,  2)
            result.leg1_pnl_unit    = round(sell_ce_entry_as - sell_ce_exit_as, 2)

            result.leg2_desc        = f"SELL PE {int(sell_pe)}"
            result.leg2_entry_price = round(sell_pe_entry, 2)
            result.leg2_exit_price  = round(sell_pe_exit,  2)
            result.leg2_pnl_unit    = round(sell_pe_entry_as - sell_pe_exit_as, 2)

            result.leg3_desc        = f"BUY  CE {int(buy_ce)}"
            result.leg3_entry_price = round(buy_ce_entry, 2)
            result.leg3_exit_price  = round(buy_ce_exit,  2)
            result.leg3_pnl_unit    = round(buy_ce_exit_as - buy_ce_entry_as, 2)

            result.leg4_desc        = f"BUY  PE {int(buy_pe)}"
            result.leg4_entry_price = round(buy_pe_entry, 2)
            result.leg4_exit_price  = round(buy_pe_exit,  2)
            result.leg4_pnl_unit    = round(buy_pe_exit_as - buy_pe_entry_as, 2)

            result.combined_sell_premium = round(combined_sell,   2)
            result.combined_buy_premium  = round(combined_buy,    2)
            result.net_credit_raw        = round(net_credit_raw,  2)
            result.net_credit_after_slip = round(net_credit_slip, 2)

            result.net_pnl_per_unit  = round(net_unit,      2)
            result.net_pnl_rs        = round(net_pnl,       2)
            result.max_profit_rs     = round(max_profit_rs, 2)
            result.max_loss_rs       = round(max_loss_rs,   2)
            result.pnl_pct_of_credit = round(pnl_pct,       2)

            self._update_stats(result)
            results.append(result)

            print(f"  [{expiry}] "
                  f"Spot={spot:.0f} | "
                  f"SELL CE{int(sell_ce)}={sell_ce_entry:.1f} "
                  f"PE{int(sell_pe)}={sell_pe_entry:.1f} | "
                  f"Net Credit={net_credit_raw:.1f} | "
                  f"PnL=Rs{net_pnl:.0f}")

        return results
