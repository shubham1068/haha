"""
main.py
=======
Sirf yeh file run karo — sab kuch automatically hoga.

Steps:
  1. DataLoader CSV se data load karega
  2. Strategy run hogi
  3. Results fixed format mein CSV mein save honge
  4. Summary print hogi

Run:
    python main.py
"""

from data_loader          import DataLoader
from iron_condor_strategy import IronCondorStrategy
from results              import ResultsExporter
from datetime             import time

# ═══════════════════════════════════════════════
# CONFIG — sirf yahan changes karo
# ═══════════════════════════════════════════════

# ── CSV paths ───────────────────────────────────
SPOT_CSV   = "exports/export_spot.csv"
OPTION_CSV = "exports/export_options.csv"

# ── Output ──────────────────────────────────────
OUTPUT_CSV = "output/iron_condor_results.csv"

# ── Strategy config (optional — defaults use honge) ──
STRATEGY_CONFIG = {
    "sell_ce_mult"  : 1.007,   # CE sell strike = spot × 1.007
    "buy_ce_mult"   : 1.015,   # CE hedge strike = spot × 1.015
    "sell_pe_mult"  : 0.993,   # PE sell strike = spot × 0.993
    "buy_pe_mult"   : 0.985,   # PE hedge strike = spot × 0.985
    "strike_step"   : 50,      # nearest 50 round
    "entry_time"    : time(9, 20),    # DTE1 entry
    "exit_time"     : time(15, 30),   # DTE0 exit
    "slippage_sell" : 0.05,
    "slippage_buy"  : 0.05,
    "lot_size"      : 75,
    "num_lots"      : 1,
}

# ═══════════════════════════════════════════════
# RUN
# ═══════════════════════════════════════════════

if __name__ == "__main__":

    # Step 1: Load data
    loader = DataLoader(SPOT_CSV, OPTION_CSV)
    loader.load()
    loader.summary()

    # Step 2: Run strategy
    strategy = IronCondorStrategy(loader, STRATEGY_CONFIG)
    trades   = strategy.run()

    # Step 3: Export results
    exporter = ResultsExporter(trades, strategy_name=strategy.strategy_name)
    exporter.save_csv(OUTPUT_CSV)

    # Step 4: Print summary
    exporter.print_summary()
