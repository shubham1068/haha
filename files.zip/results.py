"""
results.py
==========
Fixed results output — har strategy ke liye same format.
Strategy badlo, yeh file mat badlo.

Usage:
    from results import ResultsExporter

    exporter = ResultsExporter(trades, strategy_name="Iron Condor")
    exporter.save_csv("output/results.csv")
    exporter.print_summary()
"""

import pandas as pd
import os
from dataclasses import asdict
from typing import List
from strategy_base import TradeResult
from datetime import datetime


class ResultsExporter:
    """
    TradeResult list ko CSV mein save karta hai
    aur summary print karta hai.
    Format fix hai — kabhi nahi badlega.
    """

    # ── Fixed column order — kabhi mat badlo ──
    COLUMNS = [
        # Identifiers
        "trade_no", "strategy_name",
        "entry_date", "entry_day", "entry_time",
        "exit_date",  "exit_day",  "exit_time",
        "hold_days",  "expiry_date",

        # Market
        "spot_at_entry",

        # Legs
        "leg1_desc", "leg1_entry_price", "leg1_exit_price", "leg1_pnl_unit",
        "leg2_desc", "leg2_entry_price", "leg2_exit_price", "leg2_pnl_unit",
        "leg3_desc", "leg3_entry_price", "leg3_exit_price", "leg3_pnl_unit",
        "leg4_desc", "leg4_entry_price", "leg4_exit_price", "leg4_pnl_unit",

        # Premium
        "combined_sell_premium", "combined_buy_premium",
        "net_credit_raw", "net_credit_after_slip",

        # PnL
        "net_pnl_per_unit", "lot_size", "num_lots",
        "net_pnl_rs", "max_profit_rs", "max_loss_rs",
        "pnl_pct_of_credit",

        # Running
        "cumulative_pnl_rs", "peak_pnl_rs",
        "drawdown_rs", "drawdown_pct",

        # Outcome
        "is_winner", "skipped", "skip_reason",
    ]

    def __init__(self, trades: List[TradeResult], strategy_name: str = ""):
        self.trades        = trades
        self.strategy_name = strategy_name
        self._df           = None
        self._build_df()

    def _build_df(self):
        rows = [asdict(t) for t in self.trades]
        df   = pd.DataFrame(rows)

        # Keep only valid trades for stats (not skipped)
        # Reorder columns to fixed order
        existing_cols = [c for c in self.COLUMNS if c in df.columns]
        self._df = df[existing_cols]

    # ─────────────────────────────────────────
    # SAVE CSV
    # ─────────────────────────────────────────

    def save_csv(self, filepath: str):
        """Save to CSV with fixed column order."""
        out_dir = os.path.dirname(filepath)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

        self._df.to_csv(filepath, index=False)
        print(f"✓ CSV saved: {filepath}  ({len(self._df)} rows)")

    # ─────────────────────────────────────────
    # PRINT SUMMARY — fixed format
    # ─────────────────────────────────────────

    def print_summary(self):
        df       = self._df
        valid    = df[df["skipped"] == False].copy()
        skipped  = df[df["skipped"] == True]

        if valid.empty:
            print("No valid trades to summarize.")
            return

        total      = len(valid)
        wins       = valid["is_winner"].sum()
        losses     = total - wins
        total_pnl  = valid["net_pnl_rs"].sum()
        avg_pnl    = valid["net_pnl_rs"].mean()
        best       = valid["net_pnl_rs"].max()
        worst      = valid["net_pnl_rs"].min()
        max_dd_pct = valid["drawdown_pct"].max()
        max_dd_rs  = valid["drawdown_rs"].max()

        # Calmar ratio
        first_date = pd.to_datetime(valid["entry_date"].min())
        last_date  = pd.to_datetime(valid["exit_date"].max())
        years      = max((last_date - first_date).days / 365.25, 0.01)
        annual_pnl = total_pnl / years
        calmar     = annual_pnl / max_dd_rs if max_dd_rs > 0 else 0.0

        # Avg premiums
        avg_sell_premium  = valid["combined_sell_premium"].mean()
        avg_net_credit    = valid["net_credit_after_slip"].mean()
        avg_max_profit    = valid["max_profit_rs"].mean()
        avg_max_loss      = valid["max_loss_rs"].mean()

        # Streak
        pnl_series  = valid["net_pnl_rs"].values
        max_win_streak  = self._max_streak(pnl_series, win=True)
        max_loss_streak = self._max_streak(pnl_series, win=False)

        print(f"\n{'═'*62}")
        print(f"  Strategy     : {self.strategy_name}")
        print(f"  Period       : {valid['entry_date'].min()} → {valid['exit_date'].max()}")
        print(f"{'─'*62}")
        print(f"  Trades       : {total}  (Skipped: {len(skipped)})")
        print(f"  Wins         : {wins}  ({wins/total*100:.1f}%)")
        print(f"  Losses       : {losses}  ({losses/total*100:.1f}%)")
        print(f"  Win streak   : {max_win_streak}  |  Loss streak: {max_loss_streak}")
        print(f"{'─'*62}")
        print(f"  Total PnL    : Rs {total_pnl:>12,.0f}")
        print(f"  Annual PnL   : Rs {annual_pnl:>12,.0f}")
        print(f"  Avg/Trade    : Rs {avg_pnl:>12,.0f}")
        print(f"  Best Trade   : Rs {best:>12,.0f}")
        print(f"  Worst Trade  : Rs {worst:>12,.0f}")
        print(f"{'─'*62}")
        print(f"  Max DD (Rs)  : Rs {max_dd_rs:>12,.0f}")
        print(f"  Max DD (%)   :    {max_dd_pct:>11.2f}%")
        print(f"  Calmar Ratio :    {calmar:>11.2f}")
        print(f"{'─'*62}")
        print(f"  Avg SELL Premium  : {avg_sell_premium:.2f} pts")
        print(f"  Avg Net Credit    : {avg_net_credit:.2f} pts (after slip)")
        print(f"  Avg Max Profit/tr : Rs {avg_max_profit:,.0f}")
        print(f"  Avg Max Loss/tr   : Rs {avg_max_loss:,.0f}")
        print(f"{'═'*62}\n")

    @staticmethod
    def _max_streak(arr, win: bool) -> int:
        """Max consecutive win or loss streak."""
        max_s = cur_s = 0
        for v in arr:
            if (win and v > 0) or (not win and v <= 0):
                cur_s += 1
                max_s  = max(max_s, cur_s)
            else:
                cur_s = 0
        return max_s

    def get_dataframe(self) -> pd.DataFrame:
        return self._df.copy()
