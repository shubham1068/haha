"""
strategy_base.py
================
Base class — har strategy isko inherit karegi.
Results ka format yahan fix hai — strategy change hogi, columns nahi.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from typing import List, Optional
from datetime import date
import pandas as pd


# ═══════════════════════════════════════════════
# FIXED RESULT STRUCTURE
# Yeh kabhi change nahi hoga — sirf fields add ho sakte hain
# ═══════════════════════════════════════════════

@dataclass
class TradeResult:
    """
    Ek trade ka fixed result format.
    Har strategy ke liye same columns.
    """
    # ── Identifiers ──────────────────────────
    trade_no          : int   = 0
    strategy_name     : str   = ""
    entry_date        : str   = ""
    entry_day         : str   = ""
    entry_time        : str   = ""
    exit_date         : str   = ""
    exit_day          : str   = ""
    exit_time         : str   = ""
    hold_days         : int   = 0
    expiry_date       : str   = ""

    # ── Market info ──────────────────────────
    spot_at_entry     : float = 0.0

    # ── Legs (up to 4) ───────────────────────
    leg1_desc         : str   = ""   # e.g. "SELL CE 18350"
    leg1_entry_price  : float = 0.0
    leg1_exit_price   : float = 0.0
    leg1_pnl_unit     : float = 0.0

    leg2_desc         : str   = ""   # e.g. "SELL PE 18100"
    leg2_entry_price  : float = 0.0
    leg2_exit_price   : float = 0.0
    leg2_pnl_unit     : float = 0.0

    leg3_desc         : str   = ""   # e.g. "BUY CE 18550" (hedge)
    leg3_entry_price  : float = 0.0
    leg3_exit_price   : float = 0.0
    leg3_pnl_unit     : float = 0.0

    leg4_desc         : str   = ""   # e.g. "BUY PE 17900" (hedge)
    leg4_entry_price  : float = 0.0
    leg4_exit_price   : float = 0.0
    leg4_pnl_unit     : float = 0.0

    # ── Premium summary ───────────────────────
    combined_sell_premium : float = 0.0   # CE sell + PE sell (raw)
    combined_buy_premium  : float = 0.0   # CE hedge + PE hedge (raw)
    net_credit_raw        : float = 0.0   # sell - buy (before slip)
    net_credit_after_slip : float = 0.0   # after slippage

    # ── PnL ──────────────────────────────────
    net_pnl_per_unit  : float = 0.0
    lot_size          : int   = 75
    num_lots          : int   = 1
    net_pnl_rs        : float = 0.0   # net_pnl_per_unit × lot_size × num_lots
    max_profit_rs     : float = 0.0   # max possible profit this trade
    max_loss_rs       : float = 0.0   # max possible loss this trade
    pnl_pct_of_credit : float = 0.0   # net_pnl / net_credit × 100

    # ── Running stats ─────────────────────────
    cumulative_pnl_rs : float = 0.0
    peak_pnl_rs       : float = 0.0
    drawdown_rs       : float = 0.0
    drawdown_pct      : float = 0.0

    # ── Trade outcome ─────────────────────────
    is_winner         : bool  = False
    skipped           : bool  = False
    skip_reason       : str   = ""


# ═══════════════════════════════════════════════
# BASE STRATEGY CLASS
# ═══════════════════════════════════════════════

class BaseStrategy(ABC):
    """
    Har strategy isko inherit karegi.
    run() call karo → List[TradeResult] milega.
    """

    def __init__(self, data_loader, config: dict = None):
        """
        Args:
            data_loader : DataLoader instance (already loaded)
            config      : Strategy parameters dict
        """
        self.loader  = data_loader
        self.config  = config or {}

        # Running state
        self._cumulative_pnl = 0.0
        self._peak_pnl       = 0.0
        self._trade_no       = 1
        self._results        = []

    @property
    @abstractmethod
    def strategy_name(self) -> str:
        """Strategy ka naam — har subclass mein define karo."""
        pass

    @abstractmethod
    def generate_trades(self) -> List[TradeResult]:
        """
        Strategy logic yahan likhni hai subclass mein.
        Return: List of TradeResult
        """
        pass

    def run(self) -> List[TradeResult]:
        """Main entry point — yahi call karo."""
        print(f"Running strategy: {self.strategy_name}")
        print("─" * 50)
        self._results = self.generate_trades()
        print(f"\n✓ Done — {len(self._results)} trades processed.")
        return self._results

    # ─────────────────────────────────────────
    # HELPER — update running stats on result
    # ─────────────────────────────────────────

    def _update_stats(self, result: TradeResult):
        """Cumulative PnL aur drawdown update karo."""
        self._cumulative_pnl      += result.net_pnl_rs
        self._peak_pnl             = max(self._peak_pnl, self._cumulative_pnl)
        drawdown_rs                = self._peak_pnl - self._cumulative_pnl
        drawdown_pct               = (drawdown_rs / self._peak_pnl * 100) \
                                     if self._peak_pnl > 0 else 0.0

        result.cumulative_pnl_rs   = round(self._cumulative_pnl, 2)
        result.peak_pnl_rs         = round(self._peak_pnl, 2)
        result.drawdown_rs         = round(drawdown_rs, 2)
        result.drawdown_pct        = round(drawdown_pct, 2)
        result.is_winner           = result.net_pnl_rs > 0
        result.trade_no            = self._trade_no
        result.strategy_name       = self.strategy_name

        self._trade_no += 1

    # ─────────────────────────────────────────
    # HELPER — round strike
    # ─────────────────────────────────────────

    @staticmethod
    def round_strike(val: float, step: int = 50) -> float:
        return float(int(round(val / step)) * step)
